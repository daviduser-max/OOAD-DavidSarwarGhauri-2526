﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DokterspraktijkLib
{
    public static  class PatientService
    {
        public static Patient ValideerInloggen(string email, string wachtwoord)
        {
            using (SqlConnection conn = Database.GetConnection()) {
                string query = "SELECT id, voornaam, achternaam, email, gsm FROM Patient WHERE email = @Email AND paswoord = @Passwoord";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Passwoord", wachtwoord);

                try
                {
                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        Patient patient = new Patient
                        {
                            Id = Convert.ToInt32(reader["id"]),
                            Voornaam = reader["Voornaam"].ToString(),
                            Achternaam = reader["achternaam"].ToString(),
                            Email = reader["email"].ToString(),
                            Gsm = reader["gsm"].ToString()
                        };
                        return patient;
                    }
                }
                catch (Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine("Database fout: " + ex.Message);
                }
                return null;
             }
       }
    }
}
